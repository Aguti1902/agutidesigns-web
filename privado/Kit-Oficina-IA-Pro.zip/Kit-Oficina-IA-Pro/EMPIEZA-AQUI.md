# Tu oficina de IA (Pro · 8 agentes) · empieza aquí

Gracias por comprar el kit. En unos 30-60 minutos tendrás un equipo de agentes de IA trabajando para tu negocio y un panel con tu oficina en 3D donde lo ves todo.

## Qué hay en este kit
| Archivo | Para qué sirve |
|---|---|
| `GUIA-DE-INSTALACION.pdf` | La guía paso a paso, con capturas de lo que verás. |
| `INSTALAR-CON-CLAUDE.md` | El texto que pegas en Claude para que lo instale por ti. |
| `mi-negocio.md` | La ficha de tu negocio: lo único que saben tus agentes. |
| `panel/panel.html` | Tu panel con la oficina 3D, las aprobaciones, los clientes y las tareas. |
| `agentes/` | Los 8 agentes: Recepción, Ventas, Redes sociales, Vídeos, Blog y SEO, Google Business, Reseñas e Informe diario. |

## Lo que necesitas
1. **Una cuenta de Claude de pago** que incluya tareas programadas y conectores. Compruébalo en claude.ai antes de empezar: el kit funciona dentro de Claude.
2. **Gmail** (o Google Workspace) conectado en Claude, para los agentes que leen y contestan correos.
3. Unos minutos para rellenar `mi-negocio.md`.

## En 3 pasos
1. Rellena `mi-negocio.md` (o deja que Claude te lo pregunte).
2. Abre Claude, adjunta todo el kit y pega el texto de `INSTALAR-CON-CLAUDE.md`.
3. Cada día, entra en tu panel: aprueba o descarta lo que te proponen tus agentes y haz las tareas que te dejan.

## Antes de empezar, lo que tienes que saber
- Tus agentes escriben **en tu nombre**: empieza revisando lo que hacen (todo lo delicado pasa por «Esperan tu visto bueno») y dales más libertad cuando te fíes.
- Solo saben lo que pongas en `mi-negocio.md`: no inventarán precios ni datos.
- Las herramientas que conectes (Gmail, redes…) pueden tener su propio coste o límites.
- Es tuyo: cambia los textos de los agentes, sus horarios, sus nombres y el panel como quieras.

¿Prefieres que te lo monte un profesional, adaptado a tu negocio? Escríbenos: info@agutidesigns.io · agutidesigns.io/oficina-ia
