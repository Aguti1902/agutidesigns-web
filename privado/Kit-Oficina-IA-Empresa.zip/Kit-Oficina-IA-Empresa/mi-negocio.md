# Mi negocio

Rellena esto (o deja que Claude te lo pregunte al instalar). Es lo **único** que saben tus agentes de tu negocio: lo que no esté aquí, no lo dirán. Cuanto más concreto, mejor trabajan.

## Lo básico
- **Nombre del negocio:**
- **A qué te dedicas (en una frase):**
- **Ciudad / zona donde trabajas:**
- **Web:**
- **Tu nombre (el dueño) y cómo firmas los correos:**
- **Tu email (para el informe diario):**
- **Teléfono / WhatsApp de contacto:**
- **Horario:**
- **Zona horaria:** Europe/Madrid

## Lo que vendes
Lista cada servicio o producto, con precio solo si quieres que los agentes lo digan.

| Servicio o producto | Para quién es | Precio (opcional) |
|---|---|---|
| | | |

## Cómo se compra o se reserva
- **El siguiente paso que proponen los agentes** (llamada de 15 min, reservar cita, comprar en la web…):
- **Enlace para reservar o comprar:**
- **Enlace de reseñas de Google:**

## Tu cliente
- **Quién es tu cliente ideal:**
- **Sus dudas más frecuentes (y tus respuestas):**
  1.
  2.
  3.

## Pruebas reales (solo datos ciertos)
- Casos de clientes, resultados o cifras que puedan mencionar:

## Tono
- **Tú o usted:**
- **Cómo hablas** (cercano, profesional, divertido…):
- **Palabras o promesas prohibidas:**

## Redes
- Instagram:
- TikTok:
- Otras:
- **Posts a la semana:** 3

## Anuncios y cobros (para Álex y Max)
- **Plataformas de anuncios que usas:**
- **Tope de gasto al mes en anuncios:**
- **Herramienta de facturación:**
- **Días para recordar un pago pendiente:** 15
